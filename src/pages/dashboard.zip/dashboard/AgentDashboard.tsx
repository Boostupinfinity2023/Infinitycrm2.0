import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import ReactApexChart from 'react-apexcharts';
import { useDispatch, useSelector } from 'react-redux';
import { IRootState } from '../../store';
import Dropdown from '../../components/Dropdown';
import { setPageTitle } from '../../store/themeConfigSlice';
import IconHorizontalDots from '../../components/Icon/IconHorizontalDots';
import IconEye from '../../components/Icon/IconEye';
import { Table, TableHeader, TableColumn, TableBody, TableRow, TableCell } from "@nextui-org/react";
import Token from '../../getLoggedUser/GetUserInfomation';
import { v1Dashboard } from '../../APIurl/url';
import { DatePicker, Space } from 'antd';
const { RangePicker } = DatePicker;
const Analytics = () => {
    const JwtToken = Token('jwt');
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Analytics Admin'));
    });

    const [AgentData, SetAgentData]: any = useState();
    const [Chartdata, Setchartdata]: any = useState();

    const [loading] = useState(false);
    const isDark = useSelector((state: IRootState) => state.themeConfig.theme === 'dark' || state.themeConfig.isDarkMode);
    const isRtl = useSelector((state: IRootState) => state.themeConfig.rtlClass) === 'rtl' ? true : false;
    useEffect(() => {
        const Client = async () => {
            try {
                const responseData: any = await fetch(v1Dashboard + '?action=view.client.record', {
                    method: 'POST',
                    headers: {
                        Authenticate: `Bearer ${JwtToken}`,
                        'x-token-access': 'true',
                    },
                    body: JSON.stringify({
                        PAGE_REQUEST: 'AGENTDATA_DASHBOARD',
                        RequesterUser: 'agent',
                    }),
                });
                const data = await responseData.json();
                SetAgentData(await data.data[0])

            } catch (err) {
                console.error(err);

            }
        }

        const Chartback = async () => {
            try {
                const responseData: any = await fetch(v1Dashboard + '?action=view.client.record', {
                    method: 'POST',
                    headers: {
                        Authenticate: `Bearer ${JwtToken}`,
                        'x-token-access': 'true',
                    },
                    body: JSON.stringify({
                        PAGE_REQUEST: 'AGENTDATA_DASHBOARD_CHART',
                        RequesterUser: 'agent',
                    }),
                });
                const data = await responseData.json();
                Setchartdata(await data.data)

            } catch (err) {
                console.error(err);

            }
        }
        Client();
        Chartback();
    }, []);


    //Revenue Chart
    const revenueChart: any = {
        series: [
            {
                name: 'Accepted',
                data: Chartdata?.InHand || [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            },
            {
                name: 'On hold',
                data: Chartdata?.OnHold || [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
            },

        ],
        options: {
            chart: {
                height: 325,
                type: 'area',
                fontFamily: 'Nunito, sans-serif',
                zoom: {
                    enabled: false,
                },
                toolbar: {
                    show: false,
                },
            },

            dataLabels: {
                enabled: false,
            },
            stroke: {
                show: true,
                curve: 'smooth',
                width: 2,
                lineCap: 'square',
            },
            dropShadow: {
                enabled: true,
                opacity: 0.2,
                blur: 10,
                left: -7,
                top: 22,
            },
            colors: isDark ? ['#2daa0f', '#E7515A'] : ['#2daa0f', '#E7515A'],
            markers: {
                discrete: [
                    {
                        seriesIndex: 0,
                        dataPointIndex: 6,
                        fillColor: '#2daa0f',
                        strokeColor: 'transparent',
                        size: 7,
                    },
                    {
                        seriesIndex: 1,
                        dataPointIndex: 5,
                        fillColor: '#E7515A',
                        strokeColor: 'transparent',
                        size: 7,
                    },
                ],
            },
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            xaxis: {
                axisBorder: {
                    show: false,
                },
                axisTicks: {
                    show: false,
                },
                crosshairs: {
                    show: true,
                },
                labels: {
                    offsetX: isRtl ? 2 : 0,
                    offsetY: 5,
                    style: {
                        fontSize: '12px',
                        cssClass: 'apexcharts-xaxis-title',
                    },
                },
            },
            yaxis: {
                tickAmount: 7,
                labels: {
                    formatter: (value: number) => {
                        return value;
                    },
                    offsetX: isRtl ? -30 : -10,
                    offsetY: 0,
                    style: {
                        fontSize: '12px',
                        cssClass: 'apexcharts-yaxis-title',
                    },
                },
                opposite: isRtl ? true : false,
            },
            grid: {
                borderColor: isDark ? '#191E3A' : '#E0E6ED',
                strokeDashArray: 5,
                xaxis: {
                    lines: {
                        show: true,
                    },
                },
                yaxis: {
                    lines: {
                        show: false,
                    },
                },
                padding: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0,
                },
            },
            legend: {
                position: 'top',
                horizontalAlign: 'right',
                fontSize: '16px',
                markers: {
                    width: 10,
                    height: 10,
                    offsetX: -2,
                },
                itemMargin: {
                    horizontal: 10,
                    vertical: 5,
                },
            },
            tooltip: {
                marker: {
                    show: true,
                },
                x: {
                    show: false,
                },
            },
            fill: {
                type: 'gradient',
                gradient: {
                    shadeIntensity: 1,
                    inverseColors: !1,
                    opacityFrom: isDark ? 0.19 : 0.28,
                    opacityTo: 0.05,
                    stops: isDark ? [100, 100] : [45, 100],
                },
            },
        },
    };



    return (
        <div>


            <div className="pt-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-6 mb-6 text-white">
                    <div className="panel " style={{ background: 'linear-gradient(0deg, rgb(39 78 157) -227%, rgb(37 61 141))' }}>
                        <div className="flex justify-between">
                            <div className="ltr:mr-1 rtl:ml-1 text-md font-semibold">Task</div>
                            <div className="dropdown">
                                <IconHorizontalDots className="hover:opacity-80 opacity-70" />
                            </div>
                        </div>
                        <div className="flex items-center mt-5">
                            <div className="text-3xl font-bold ltr:mr-3 rtl:ml-3"> 0 </div>
                            {/* <div className="badge bg-white/30">+ 2.35% </div> */}
                        </div>
                        <div className="flex items-center font-semibold mt-5">
                            <IconEye className="ltr:mr-2 rtl:ml-2 shrink-0" />
                            Last Week 0
                        </div>
                    </div>

                    {/* Sessions */}
                    <div className="panel " style={{ background: 'linear-gradient(0deg, rgb(36 134 200) -227%, rgb(36 134 200))' }}>
                        <div className="flex justify-between">
                            <div className="ltr:mr-1 rtl:ml-1 text-md font-semibold">Applications</div>
                            <div className="dropdown">
                                <IconHorizontalDots className="hover:opacity-80 opacity-70" />
                            </div>
                        </div>
                        <div className="flex items-center mt-5">
                            <div className="text-3xl font-bold ltr:mr-3 rtl:ml-3"> {AgentData?.Total_Apllication || 0} </div>
                            {/* <div className="badge bg-white/30">- 2.35% </div> */}
                        </div>
                        <div className="flex items-center font-semibold mt-5">
                            <IconEye className="ltr:mr-2 rtl:ml-2 shrink-0" />
                            Last Week {AgentData?.Total_Apllication_last_week || 0}
                        </div>
                    </div>

                    {/*  Time On-Site */}
                    <div className="panel " style={{ background: 'linear-gradient(0deg, rgb(51 134 66) -227%, rgb(51, 134, 66))' }}>

                        <div className="flex justify-between">
                            <div className="ltr:mr-1 rtl:ml-1 text-md font-semibold">Accepted</div>
                            <div className="dropdown">
                                <IconHorizontalDots className="hover:opacity-80 opacity-70" />
                            </div>
                        </div>
                        <div className="flex items-center mt-5">
                            <div className="text-3xl font-bold ltr:mr-3 rtl:ml-3"> {AgentData?.Total_Apllication_Accepted || 0} </div>
                            {/* <div className="badge bg-white/30">+ 1.35% </div> */}
                        </div>
                        <div className="flex items-center font-semibold mt-5">
                            <IconEye className="ltr:mr-2 rtl:ml-2 shrink-0" />
                            Last Week {AgentData?.Total_Apllication_Accepted_last_week || 0}
                        </div>
                    </div>

                    {/* Bounce Rate */}
                    <div className="panel " style={{ background: 'linear-gradient(0deg, rgb(194 26 40) -227%, rgb(194, 26, 40))' }}>
                        <div className="flex justify-between">
                            <div className="ltr:mr-1 rtl:ml-1 text-md font-semibold">Rejected</div>
                            <div className="dropdown">
                                <IconHorizontalDots className="hover:opacity-80 opacity-70" />
                            </div>
                        </div>
                        <div className="flex items-center mt-5">
                            <div className="text-3xl font-bold ltr:mr-3 rtl:ml-3"> {AgentData?.Total_Apllication_Rejected || 0} </div>
                            {/* <div className="badge bg-white/30">- 0.35% </div> */}
                        </div>
                        <div className="flex items-center font-semibold mt-5">
                            <IconEye className="ltr:mr-2 rtl:ml-2 shrink-0" />
                            Last Week {AgentData?.Total_Apllication_Rejected_last_week || 0}
                        </div>
                    </div>

                    <div className="panel" style={{ background: 'linear-gradient(0deg, rgb(255 191 0) -227%, rgb(225 169 0))' }}>
                        <div className="flex justify-between">
                            <div className="ltr:mr-1 rtl:ml-1 text-md font-semibold">Total Student</div>
                            <div className="dropdown">
                                <IconHorizontalDots className="hover:opacity-80 opacity-70" />
                            </div>
                        </div>
                        <div className="flex items-center mt-5">
                            <div className="text-3xl font-bold ltr:mr-3 rtl:ml-3">{AgentData?.Total_Students || 0}</div>
                            {/* <div className="badge bg-white/30">- 0.35% </div> */}
                        </div>
                        <div className="flex items-center font-semibold mt-5">
                            <IconEye className="ltr:mr-2 rtl:ml-2 shrink-0" />
                            Last Week {AgentData?.Total_Students_last_week || 0}
                        </div>
                    </div>
                </div>



            </div>

            <div className="pt-5">
                <div className="grid ">
                    <div className="grid  gap-6 mb-6">
                        <div className="panel h-full ">
                            <div className="flex items-center justify-between dark:text-white-light mb-5">
                                <h5 className="font-semibold text-lg">Accepted and Rejected</h5>
                                <div className="dropdown">
                                    <Space direction="vertical">
                                        <RangePicker picker="month" />

                                    </Space>
                                </div>
                            </div>

                            <div className="relative">
                                <div className="bg-white dark:bg-black rounded-lg overflow-hidden">
                                    {loading ? (
                                        <div className="min-h-[325px] grid place-content-center bg-white-light/30 dark:bg-dark dark:bg-opacity-[0.08] ">
                                            <span className="animate-spin border-2 border-black dark:border-white !border-l-transparent  rounded-full w-5 h-5 inline-flex"></span>
                                        </div>
                                    ) : (
                                        <ReactApexChart series={revenueChart.series} options={revenueChart.options} type="area" height={325} />
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="grid lg:grid-cols-3 gap-6 mb-6">
                    {/* <div className="panel h-full p-0 lg:col-span-2"> */}
                    {/* <div className="flex items-start justify-between dark:text-white-light mb-5 p-5 border-b  border-white-light dark:border-[#1b2e4b]"> */}
                    {/* <h5 className="font-semibold text-lg ">Files</h5>
                            <div className="dropdown">
                                <Dropdown
                                    offset={[0, 5]}
                                    placement={`${isRtl ? 'bottom-start' : 'bottom-end'}`}
                                    btnClassName="hover:text-primary"
                                    button={<IconHorizontalDots className="text-black/70 dark:text-white/70 hover:!text-primary" />}
                                >
                                    <ul>
                                        <li>
                                            <button type="button">View</button>
                                        </li>
                                        <li>
                                            <button type="button">Update</button>
                                        </li>
                                        <li>
                                            <button type="button">Delete</button>
                                        </li>
                                    </ul>
                                </Dropdown>
                            </div> */}
                    {/* </div> */}

                    {/* <ReactApexChart options={uniqueVisitorSeries.options} series={uniqueVisitorSeries.series} type="bar" height={360} className="overflow-hidden" /> */}
                    {/* </div> */}
                    <div className="panel h-full w-full col-span-2">
                        <div className="flex items-center justify-between mb-5">
                            <h5 className="font-semibold text-lg dark:text-white-light">Task management</h5>
                        </div>
                        <div className="table-responsive">
                            <Table removeWrapper aria-label="Example static collection table"

                            >
                                <TableHeader>
                                    <TableColumn>Task Title</TableColumn>
                                    <TableColumn>Application</TableColumn>
                                    <TableColumn>School</TableColumn>
                                    <TableColumn>Due date</TableColumn>
                                </TableHeader>
                                <TableBody>
                                    <TableRow key="1">
                                        <TableCell className='text-blue-500'><Link to={''}>(IELTS) International English Language Testing System</Link></TableCell>
                                        <TableCell>#4635526</TableCell>
                                        <TableCell>Algoma University - Brampton</TableCell>
                                        <TableCell>Today</TableCell>
                                    </TableRow>
                                    <TableRow key="1">
                                        <TableCell className='text-blue-500'><Link to={''}>(IELTS) International English Language Testing System</Link></TableCell>
                                        <TableCell>#4635526</TableCell>
                                        <TableCell>Algoma University - Brampton</TableCell>
                                        <TableCell>Today</TableCell>
                                    </TableRow>
                                    <TableRow key="1">
                                        <TableCell className='text-blue-500'><Link to={''}>(IELTS) International English Language Testing System</Link></TableCell>
                                        <TableCell>#4635526</TableCell>
                                        <TableCell>Algoma University - Brampton</TableCell>
                                        <TableCell>Today</TableCell>
                                    </TableRow>

                                </TableBody>
                            </Table>
                        </div>
                    </div>
                    <div className="panel h-full">
                        <div className="flex items-start justify-between dark:text-white-light mb-5 -mx-5 p-5 pt-0 border-b  border-white-light dark:border-[#1b2e4b]">
                            <h5 className="font-semibold text-lg ">Your balance</h5>
                            <div className="dropdown">
                                <Dropdown
                                    offset={[0, 5]}
                                    placement={`${isRtl ? 'bottom-start' : 'bottom-end'}`}
                                    btnClassName="hover:text-primary"
                                    button={<IconHorizontalDots className="text-black/70 dark:text-white/70 hover:!text-primary" />}
                                >
                                    <ul>
                                        <li>
                                            <button type="button">View All</button>
                                        </li>
                                        <li>
                                            <button type="button">Mark as Read</button>
                                        </li>
                                    </ul>
                                </Dropdown>
                            </div>
                        </div>
                        <div>
                            <div className="flex justify-between gap-6">
                                <dt className="text-xl leading-loose tracking-wide font-medium">Commissions</dt>
                                <dd className="text-xl leading-loose tracking-wide font-medium">
                                    <div className="css-anbbrp">$0.00 CAD</div>
                                </dd>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    );
};

export default Analytics;
