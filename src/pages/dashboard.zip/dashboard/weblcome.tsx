export default function Welcome()
{
    return(
        <blockquote>
            <p className="text-lg font-medium">
                “ Hello and welcome to Skyline CRM! Let's embark on a journey to streamline your customer management. ”
            </p>
        </blockquote>
    );
}